package com.hostbooks.studentApplication.controller;

import com.hostbooks.studentApplication.entities.Course;
import com.hostbooks.studentApplication.entities.Student;
import com.hostbooks.studentApplication.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@CrossOrigin("http://localhost:4200/")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @PostMapping("api/course")
    ResponseEntity<String> saveCourseController(@RequestBody Course course){

        String message = courseService.saveCourseDetails(course);

        return  new ResponseEntity<String>(message, HttpStatus.ACCEPTED);

    }

    @GetMapping("api/course")
    ResponseEntity<List<Course>> getAllCoursesController(){

        List<Course> courses = courseService.getAllCourses();

        return  new ResponseEntity<List<Course>>(courses, HttpStatus.ACCEPTED);

    }

    @GetMapping("api/course/{courseId}")
    ResponseEntity<Course> getCourseByStudentIdController(@Valid @PathVariable Integer courseId){

       Course courses = courseService.getCourseByCourseId(courseId);

       return new  ResponseEntity<Course>(courses, HttpStatus.ACCEPTED);
    }

}
