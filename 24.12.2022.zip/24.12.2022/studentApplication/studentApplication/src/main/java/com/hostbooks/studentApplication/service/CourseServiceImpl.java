package com.hostbooks.studentApplication.service;

import com.hostbooks.studentApplication.entities.Course;
import com.hostbooks.studentApplication.entities.Student;
import com.hostbooks.studentApplication.exception.CourseException;
import com.hostbooks.studentApplication.exception.StudentException;
import com.hostbooks.studentApplication.repository.CourseDao;
import com.hostbooks.studentApplication.repository.StudentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseServiceImpl implements CourseService{

    @Autowired
    private CourseDao cDao;

    @Autowired
    private StudentDao sDao;

    @Override
    public String saveCourseDetails(Course course) throws CourseException {

            cDao.save(course);
            return "Course added";


    }

    @Override
    public Course getCoursesByStudentId(Integer stdId) throws StudentException {

        Optional<Student> optional =  sDao.findById(stdId);
        if(!optional.isPresent())
        {
          throw  new StudentException("Student not found with : " + stdId);
        }
        else
        {
            Student student = optional.get();
            Course courses = student.getCourse();

                return courses;

        }

    }

    @Override
    public List<Course> getAllCourses() throws CourseException {

        List<Course> courses = cDao.findAll();
        if(courses.size()>0)
        {
            return courses;
        }
        else
        {
            throw new CourseException("No courses available");
        }
    }

    @Override
    public Course getCourseByCourseId(Integer courseId) throws CourseException {

       Optional<Course> optional =  cDao.findById(courseId);
        if(optional.isPresent())
        {
            return optional.get();
        }
        else
        {
            throw  new CourseException("No course is not with : " + courseId);
        }
    }


}
