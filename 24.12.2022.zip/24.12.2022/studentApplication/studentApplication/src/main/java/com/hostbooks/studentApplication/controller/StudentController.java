package com.hostbooks.studentApplication.controller;


import com.hostbooks.studentApplication.dto.StudentDto;
import com.hostbooks.studentApplication.entities.Student;
import com.hostbooks.studentApplication.exception.MyError;
import com.hostbooks.studentApplication.service.AddressService;
import com.hostbooks.studentApplication.service.StudentService;
import com.hostbooks.studentApplication.validator.StudentUpdateValidator;
import com.hostbooks.studentApplication.validator.StudentValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.List;

@RestController
//@RequestMapping("/api/students")
@CrossOrigin("http://localhost:4200/")
public class StudentController {

    @Autowired
    private StudentService sService;

    @Autowired
    private AddressService aService;


    @Qualifier("validator")
    @Autowired
    private StudentValidator studentValidator;
    @InitBinder
    //("Student")
    public void initBinder(WebDataBinder binder){
        binder.setValidator(studentValidator);
    }

    @PostMapping("api/students/{courseId}")
    ResponseEntity<?> createStudentController(@Valid @RequestBody Student std,
                                              @PathVariable Integer courseId, Errors error, WebRequest wr){

//        studentValidator.validate(std,error);
//          new StudentValidator().validate(std,valid );
//           new StudentUpdateValidator().validate(std,valid);

        if(error.hasErrors())
        {
            MyError myError = new MyError(LocalDate.now(), error.getFieldError().getDefaultMessage(), wr.getDescription(false));
            return  new ResponseEntity<>("hi bro",HttpStatus.OK);
        }

        Student  stds =  sService.saveStudents(std, courseId);
        return new ResponseEntity<>(stds,HttpStatus.CREATED);
    }



    @GetMapping("api/students/{Id}")
    ResponseEntity<Student> getStudentByStudentIdController(@PathVariable Integer Id){

        Student stds =  sService.getStudentByStudentId(Id);

        return new ResponseEntity<Student>(stds,HttpStatus.ACCEPTED);
    }

    @GetMapping("api/students")
    ResponseEntity<List<Student>> getAllStudentController(){
        List<Student> stds = sService.getAllStudent();

        return new ResponseEntity<List<Student>>(stds,HttpStatus.ACCEPTED);
    }




    @PutMapping("api/students/{Id}")
    ResponseEntity<Student> updateStudentByIdController(@RequestBody Student std ,@PathVariable Integer Id, Errors errors){

//        new StudentUpdateValidator().validate(std,valid);

        Student stds =  sService.updateStudentById(std, Id);

        return new ResponseEntity<Student>(stds,HttpStatus.ACCEPTED);
    }



    @DeleteMapping("api/students/{Id}")
    ResponseEntity<String> deleteStudentByIdController(@PathVariable Integer Id){


        String message =  sService.deleteStudentById(Id);

        return new ResponseEntity<String>(message,HttpStatus.ACCEPTED);
    }


//    @GetMapping("api/students/{name}")
//    ResponseEntity<List<Student>> getStudentsByNameController(@PathVariable String name){
//        List<Student> stds = sService.findStudentsByName(name);
//
//        return new ResponseEntity<List<Student>>(stds,HttpStatus.ACCEPTED);
//    }



    //custom criteria query
    @GetMapping("api/studentCustom")
    ResponseEntity<List<Student>> getAllStudentCustom(){
        List<Student> stds = sService.getAllStudentCustom();

        return new ResponseEntity<List<Student>>(stds,HttpStatus.ACCEPTED);
    }

    @GetMapping("api/studentCustom/{mobile}")
    ResponseEntity<Student> getAllStudentByMobileCustom( @PathVariable String mobile){
        Student stds = sService.getStudentByMobileCustom(mobile);

        return new ResponseEntity<Student>(stds,HttpStatus.ACCEPTED);
    }

    @GetMapping("api/studentCustomDes")
    ResponseEntity<List<Student>> getAllStudentDescIdCustom(){
        List<Student> stds = sService.getAllStudentCustomDescS();

        return new ResponseEntity<List<Student>>(stds,HttpStatus.ACCEPTED);
    }


    @GetMapping("api/studentCustomNumber/{mobile}")
    ResponseEntity<Integer> getNumberOfStudentByMobileCustom( @PathVariable String mobile){
        Integer stds = sService.getNumberStudentByMobileCustomService(mobile);

        return new ResponseEntity<Integer>(stds,HttpStatus.ACCEPTED);
    }



    @PostMapping("api/studentsCustom")
    ResponseEntity<?> addStudentByDTOController(@Valid @RequestBody StudentDto studentDto, Errors error, WebRequest wr){

        if(error.hasErrors())
        {
            MyError myError = new MyError(LocalDate.now(), error.getFieldError().getDefaultMessage(), wr.getDescription(false));
            return  new ResponseEntity<>("hi bro",HttpStatus.OK);
        }

        Student  stds =  sService.addStudentByDto(studentDto);
        return new ResponseEntity<>(stds,HttpStatus.CREATED);
    }



}
