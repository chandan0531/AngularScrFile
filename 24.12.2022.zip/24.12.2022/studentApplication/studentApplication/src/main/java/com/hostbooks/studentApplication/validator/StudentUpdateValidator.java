package com.hostbooks.studentApplication.validator;

import com.hostbooks.studentApplication.entities.Student;
import com.hostbooks.studentApplication.exception.StudentException;
import com.hostbooks.studentApplication.repository.StudentDao;
import com.hostbooks.studentApplication.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

//@ControllerAdvice
//@Service
public class StudentUpdateValidator implements Validator {

    @Autowired
    private StudentService sService;

    @Autowired
    private StudentDao studentDao;

    @Override
    public boolean supports(Class<?> clazz) {

        return Student.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) throws StudentException {


//        ValidationUtils.rejectIfEmpty(errors, "gender","gender is required" );
//        ValidationUtils.rejectIfEmpty(errors,"email","email id is must required");

        Student student = (Student) target;


      Integer number =   studentDao.findAvailableMobileNo(student.getCellPhone());
        System.out.println("something1 : " + number);
        if(number > 1)
        {
//            errors.rejectValue("name", null, "Enter the student name");
//            return;
//            System.out.println("something 2: " + number);
            errors.rejectValue("cellPhone", "Student with same mobile no. is present :");
            throw new StudentException("Student with same mobile no. is present : " + student.getCellPhone());
        }


    }
}
