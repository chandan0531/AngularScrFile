package com.hostbooks.studentApplication.validator;

import com.hostbooks.studentApplication.controller.StudentController;
import com.hostbooks.studentApplication.dto.StudentDto;
import com.hostbooks.studentApplication.entities.Course;
import com.hostbooks.studentApplication.entities.Student;
import com.hostbooks.studentApplication.exception.StudentException;
import com.hostbooks.studentApplication.repository.StudentDao;
import com.hostbooks.studentApplication.service.StudentService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = StudentController.class)
@Qualifier("validator")
public class StudentValidator implements Validator {


    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private StudentService studentService;

    @Override
    public boolean supports(Class<?> clazz) {

        return Student.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {


//        ValidationUtils.rejectIfEmpty(errors, "gender","gender is required" );
//        ValidationUtils.rejectIfEmpty(errors,"email","email id is must required");

        StudentDto studentDto = (StudentDto) target;

        Student student =  modelMapper.map(studentDto,Student.class);

        System.out.println("tum" + student);
        if(student.getName().length()<= 0 || student.getName()==null)
        {
            System.out.println("hum");
            errors.reject("jkhjkdfh");
            errors.rejectValue("name", "500", "Enter the student name");

////            System.out.println("something");
//            throw  new StudentException("Enter the student name");
        }


//        Integer studentCustom =   studentService.findAvailableMobileNo(student.getCellPhone());
//        System.out.println("something1 : " + studentCustom);
//        if(studentCustom > 0){
//            errors.rejectValue("cellPhone", "500", "Student with same mobile no. is present :");
//            System.out.println("something 2: " + studentCustom);
////            throw  new StudentException("Student with same mobile no. is present : " + student.getCellPhone());
//
//        }


    }
}
