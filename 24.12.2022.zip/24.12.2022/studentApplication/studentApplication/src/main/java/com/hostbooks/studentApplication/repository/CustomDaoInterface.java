package com.hostbooks.studentApplication.repository;

import com.hostbooks.studentApplication.entities.Student;

import java.util.List;

public interface CustomDaoInterface {

    List<Student> getAllStudentCustom();

    Student getStudentByMobileCustom(String mobile);

    List<Student> getAllStudentCustomDesc();

    Integer getNumberStudentByMobileCustom(String mobile);
}
