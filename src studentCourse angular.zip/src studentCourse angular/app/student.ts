export class Student {

    studentId:any;
    name:any;
    gender:any;
    cellPhone:any;
    email:any;
    adds:any;
    course:any;
}
