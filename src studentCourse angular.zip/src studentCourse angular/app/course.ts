export class Course {

    courseId:any;
    courseName:any;
    description:any;
    courseType:any;
    duration:any;
    topics:any;
    student:any;
    
}
