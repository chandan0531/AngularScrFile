import { Component,OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Course } from '../course';
import { StudentDataService } from '../servies/student-data.service';
import { Student } from '../student';


@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit{


  courses:any=Course;
  students:any=Student;

  

  constructor(private studentService:StudentDataService,
    private router: Router){}

  ngOnInit(): void {
    
    this.getCourse();

    this.getAllStudent();

  }

// get All courses;
  getCourse(){
    this.studentService.getAllCourses().subscribe(data=>{

      console.log(data);
      this.courses = data;
    })
  }

  // get All Student;
  getAllStudent(){
    this.studentService.getStudents().subscribe(data=>{
      this.students = data;
      console.log("Student data : " + this.students[0].course.courseId)
    })
  }



  updateCourseById(x:any){

    this.router.navigate(['updateCourse',x]);
    
  }


  addStudentByCourseId(x:any){

    var flag = true;

    for(var i =0; i<this.students.length; i++)
    {
      if(this.students[i].course.courseId==x)
      {
        flag = false;
        alert("Student is alraedy added with courseId : " + x)
      }
    }
    if(flag==true)
      this.router.navigate(['saveStudent',x])
    else
    flag = true;
    
  }



 

}
