export class Address {

    addId:any;
    area:any;
    city:any;
    district:any;
    addressType:any;
    student:any;
    
}
