import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import {HttpClient} from '@angular/common/http'
import { Student } from '../student';
import { Course } from '../course';
import { Address } from '../address';

@Injectable({
  providedIn: 'root'
})
export class StudentDataService {

  url = "http://localhost:8080/api/students";

  urlC = "http://localhost:8080/api/course";

  urlA = "http://localhost:8080/api/address";

  constructor( private httpClient:HttpClient) { }


  getStudents():Observable<Student>{
    return this.httpClient.get<Student>(`${this.url}`)
  }

// get student by Id
  getStudentByStudentId(id:any):Observable<Student> {
    return this.httpClient.get<Student>(`${this.url}/${id}`)
  }
  

  // add student by course id
  addStudentByCourseId(id:any, student:Student):Observable<Object>{
    return this.httpClient.post(`${this.url}/${id}`,student)
  }


  // update student by Student id
  updateStudentByStudentId(id:any, student:Student):Observable<Object>{
    return this.httpClient.put(`${this.url}/${id}`, student);
  }

// delete student by Id
deleteStudentBystudentId(id:any):Observable<Object>{

  return this.httpClient.delete(`${this.url}/${id}`)
}


// get All courses
getAllCourses():Observable<Course>{
  return this.httpClient.get<Course>(`${this.urlC}`)
}

//add course
addCourse(course:Course):Observable<Object>{

  return this.httpClient.post(`${this.urlC}`, course)
}

//get course By Id
getCourseByCourseId(id:any):Observable<Course>{
  return this.httpClient.get<Course>(`${this.urlC}/${id}`)
}


// get All Address
getAllAddress():Observable<Address>{
  return this.httpClient.get<Address>(`${this.urlA}`)
}


//Save address by Student ID
saveAddressByStudentId(id:any, address:Address):Observable<Object>{

  return this.httpClient.post(`${this.urlA}/${id}`,address);
}






}
