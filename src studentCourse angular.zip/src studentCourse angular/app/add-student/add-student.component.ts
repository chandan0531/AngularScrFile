import { Component,OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentDataService } from '../servies/student-data.service';
import { Student } from '../student';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {
//All student list
  students:any=Student;

id:any;
student:Student = new Student();

  constructor(private studentService:StudentDataService, private router:Router,
    private route:ActivatedRoute){}


  ngOnInit(): void {
    
    this.id =  this.route.snapshot.params['id'];
    this.studentService.getCourseByCourseId(this.id).subscribe(data=>{
      console.log(data)
    },error=> console.log(error))

    this.getAllStudent();
  }




  saveStudentByCourseId(){
    this.studentService.addStudentByCourseId(this.id,this.student).subscribe(data=>{
      console.log(data)
    }, error=>console.log("My error: " + error.error))
    this.goToStudentList();
  }


  onSubmit(){
    // console.log("chandan check : " +  this.student.cellPhone)

    let flag = true;
    for(var i=0; i<this.students.length; i++)
    {
      if(this.students[i].cellPhone == this.student.cellPhone)
      {
        flag = false;
        alert("Student is already available with mobile no. : " + this.student.cellPhone)
      }
    }

    if(flag==true)
    this.saveStudentByCourseId();
    else
    flag= false;


    
  }


  goToStudentList(){
    this.router.navigate(['/students']);
  }



//get all students
getAllStudent(){
  this.studentService.getStudents().subscribe(data=>{
    this.students = data;
    console.log("Student data : " + this.students[0].cellPhone)
  })
}


}
