package com.hostbooks.studentApplication.service;

import java.util.List;
import java.util.Optional;

import com.hostbooks.studentApplication.entities.Address;
import com.hostbooks.studentApplication.entities.Course;
import com.hostbooks.studentApplication.entities.Student;
import com.hostbooks.studentApplication.exception.CourseException;
import com.hostbooks.studentApplication.exception.StudentException;
import com.hostbooks.studentApplication.repository.AddressDao;
import com.hostbooks.studentApplication.repository.CourseDao;
import com.hostbooks.studentApplication.repository.StudentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements StudentService{


    @Autowired
    private StudentDao sDao;

    @Autowired
    private AddressDao aDao;

    @Autowired
    private CourseDao cDao;

    @Override
    public Student saveStudents(Student student, Integer courseId) throws StudentException {


        Optional<Course> opt  = cDao.findById(courseId);
        if(!opt.isPresent())
        {
            throw new CourseException("Course is not available");
        }
        else
        {

            Course course =  opt.get();
            student.setCourse(course);

            course.setStudent(student);

            return sDao.save(student);

        }
    }

    @Override
    public List<Student> getAllStudent() throws StudentException {

        List<Student> students = sDao.findAll();

        if(students.size() > 0)
        {
            return students;
        }
        else
        {
            throw new StudentException("Employee Not present");
        }

    }


    @Override
    public Student updateStudentById(Student std, Integer Id) throws StudentException {

        Optional<Student> opt  = sDao.findById(Id);

        if(opt.isPresent())
        {
            sDao.save(std);
            return std;
        }

        else
        {
            throw new StudentException("Student Not present with: " + Id);
        }
    }

    @Override
    public String deleteStudentById(Integer Id) throws StudentException {


        Optional<Student> opt  = sDao.findById(Id);

        if(opt.isPresent())
        {
            Student std = opt.get();
            sDao.delete(std);
            return "Student details have been deleted with :  + Id";
        }
        else
        {
            throw new StudentException("Student Not present with: " + Id);
        }
    }

    @Override
    public Student registerStudentInCourse(String cname, Student student)throws CourseException {

        Course course= cDao.findByCourseName(cname);

        if(course != null) {

//            course.getStudents().add(student);
//            student.getCourses().add(course);
                course.setStudent(student);
                student.setCourse(course);

            return sDao.save(student);
        }
        else
        {
            throw new CourseException("Course Does not exist with Cname "+cname);
        }
    }

    @Override
    public List<Student> findStudentsByName(String name) throws StudentException {

        List<Student> students = sDao.findByName(name);

        if(students.size()> 0)
        {
            return students;
        }
        else
        {
            throw new StudentException("Student not exist with the name:  " + name);
        }


    }




}
