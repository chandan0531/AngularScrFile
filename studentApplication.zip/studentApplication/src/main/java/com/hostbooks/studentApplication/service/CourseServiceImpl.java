package com.hostbooks.studentApplication.service;

import com.hostbooks.studentApplication.entities.Course;
import com.hostbooks.studentApplication.entities.Student;
import com.hostbooks.studentApplication.exception.CourseException;
import com.hostbooks.studentApplication.exception.StudentException;
import com.hostbooks.studentApplication.repository.CourseDao;
import com.hostbooks.studentApplication.repository.StudentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseServiceImpl implements CourseService{

    @Autowired
    private CourseDao cDao;

    @Autowired
    private StudentDao sDao;

    @Override
    public String saveCourseDetails(Course course) throws CourseException {
        Optional<Course> optional = cDao.findById(course.getCourseId());

        if(!optional.isPresent())
        {
            cDao.save(course);
            return "Course added";
        }
        else {
            throw  new CourseException ("Course already available with : " + course.getCourseId());
        }

    }

    @Override
    public Course getCoursesByStudentId(Integer stdId) throws StudentException {

        Optional<Student> optional =  sDao.findById(stdId);
        if(!optional.isPresent())
        {
          throw  new StudentException("Student not found with : " + stdId);
        }
        else
        {
            Student student = optional.get();
            Course courses = student.getCourse();

                return courses;

        }

    }


}
