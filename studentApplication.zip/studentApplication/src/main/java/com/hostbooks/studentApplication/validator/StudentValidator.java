package com.hostbooks.studentApplication.validator;

import com.hostbooks.studentApplication.entities.Student;
import com.hostbooks.studentApplication.exception.StudentException;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class StudentValidator implements Validator {


    @Override
    public boolean supports(Class<?> clazz) {
        return Student.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {

        Student student = (Student) target;
        if(student.getName().length()<= 0 || student.getName()==null)
        {
//            errors.rejectValue("name", null, "Enter the student name");
//            return;
////            System.out.println("something");
            throw  new StudentException("Enter the student name");
        }

    }
}
